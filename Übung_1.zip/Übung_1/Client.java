package org.hbrs.se1.ss24.uebung1.client;

public class Client {
    
    private final NumberTransformer transformer;

    public Client(NumberTransformer transformer) {
        this.transformer = transformer;
    }

    public void printTransformation(int number) {
        String result = transformer.transformNumber();
        System.out.println("Die römische Schreibweise der Zahl " + number + " ist: " + result);
    }

    public static void main(String[] args) {
        int number = 1520;
        NumberTransformer transformer = new RomanNumberTransformer(number);
        Client client = new Client(transformer);
        client.printTransformation(number);
    }
}
