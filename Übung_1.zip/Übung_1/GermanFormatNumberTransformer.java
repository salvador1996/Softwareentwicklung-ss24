package org.hbrs.se1.ss24.uebung1.businesslogic;

import java.text.DecimalFormat;

public class GermanFormatNumberTransformer implements NumberTransformer {
    private DecimalFormat germanFormat;

    public GermanFormatNumberTransformer() {
        // Initialize DecimalFormat with German number format
        germanFormat = new DecimalFormat("#.###");
    }

    
    public String transformNumber(int number) {

        if (number < 1 || number > 3000) {
            return "Ungültige Eingabe: Die Zahl muss zwischen 1 und 3000 liegen.";
        }

        // Format the number using German number format
        return germanFormat.format(number);
    }

    
    public String getTransformerType() {
        return "Transformer für deutsche Zahlenformatierungen.";
    }
}
