package org.hbrs.se1.ss24.uebung1.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

class TestRomanNumberTransformer {

    @Test
    void TestRomanNumbers() {
         // Create RomanNumberTransformer instance
        RomanNumberTransformer transformer = new RomanNumberTransformer(450);

        // Test transformation
        assertEquals("CDL", transformer.transformNumber(), "Die römische Zahl für 450 sollte CDL sein.");
    }

    @Test
    void TestSmallestNumbers() {
         // Create RomanNumberTransformer instance
        RomanNumberTransformer transformer = new RomanNumberTransformer(1);

        // Test transformation
        assertEquals("I", transformer.transformNumber(), "Die römische Zahl für 450 sollte I sein.");
    }

    @Test
    void TestLargestNumbers() {
         // Create RomanNumberTransformer instance
        RomanNumberTransformer transformer = new RomanNumberTransformer(3000);

        // Test transformation
        assertEquals("IIIM", transformer.transformNumber(), "Die römische Zahl für 450 sollte IIIM sein.");
    }


    @Test
    void testOutOfRangeNumber() {
        // Create RomanNumberTransformer instance with number out of range
        RomanNumberTransformer transformer = new RomanNumberTransformer(3500);

        // Test if out of range message is returned
        assertEquals("Ungültige Eingabe: Die Zahl muss zwischen 1 und 3000 liegen.", transformer.transformNumber(), "Die Meldung (Außerhalb des Bereichs) sollte zurückgegeben werden");
    }

    @Test
    void testZeroNumber() {
        // Create RomanNumberTransformer instance with zero number
        RomanNumberTransformer transformer = new RomanNumberTransformer(0);

        // Test if out of range message is returned
        assertEquals("Ungültige Eingabe: Die Zahl muss zwischen 1 und 3000 liegen.", transformer.transformNumber(), "Die Meldung (Außerhalb des Bereichs) sollte zurückgegeben werden");
    }

     @Test
    void testNegativNumber() {
        // Create RomanNumberTransformer instance with zero number
        RomanNumberTransformer transformer = new RomanNumberTransformer(-10);

        // Test if out of range message is returned
        assertEquals("Ungültige Eingabe: Die Zahl muss zwischen 1 und 3000 liegen.", transformer.transformNumber(), "Die Meldung (Außerhalb des Bereichs) sollte zurückgegeben werden");
    }


}
