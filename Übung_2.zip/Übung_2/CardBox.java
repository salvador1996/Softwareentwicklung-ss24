package org.hbrs.se1.ss24.uebung2;

import java.util.ArrayList;
import java.util.List;

public class CardBox {
    private List<PersonCard> cards;

    public CardBox() {
        cards = new ArrayList<>();
    }

    // FA1
    public void addPersonCard(PersonCard personCard) throws CardBoxException {
        for (PersonCard card : cards) {
            if (card.getId() == personCard.getId()) {
                throw new CardBoxException("Das CardBox-Objekt mit der ID " + personCard.getId() + " ist bereits vorhanden");
            }
        }
        cards.add(personCard);
    }


    // FA2
    public String deletePersonCard(int id) {
        Iterator<PersonCard> iterator = cards.iterator();
        while (iterator.hasNext()) {
            PersonCard card = iterator.next();
            if (card.getId() == id) {
                iterator.remove();
            }
        }
        return "Das Personcard mit der ID " + id + " existiert nicht.";
    }

    
    // FA3
    public void showContent() {
        for (PersonCard card : cards) {
            
            if (card instanceof DeveloperCard) {
                DeveloperCard developerCard = (DeveloperCard) card;
                System.out.println("ID: " + card.getId() + "Vorname: " + card.getFirstName() + "Nachname: " + card.getLastName() + "Coffee Status: " + (developerCard.hasEnoughCoffee() ? "Enough" : "Not Enough"));
            } else if (card instanceof EnduserCard) {
                EnduserCard enduserCard = (EnduserCard) card;
                System.out.println("ID: " + card.getId() + "Vorname: " + card.getFirstName() + "Nachname: " + card.getLastName() + "Hunger Status: " + (enduserCard.isHungry() ? "Hungry" : "Not Hungry"));
            }
            
            System.out.println();
        }
    }

    // FA4
    public int size() {
        return cards.size();
    }


}
