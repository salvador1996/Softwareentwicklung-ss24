package org.hbrs.se1.ss24.uebung2;

public class CardBoxException extends Exception {
    public CardBoxException(String message) {
        super(message);
    }
}
