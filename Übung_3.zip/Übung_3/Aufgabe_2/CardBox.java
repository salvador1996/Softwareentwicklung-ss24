package org.hbrs.se1.ss24.uebung2;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class CardBox {
    private static CardBox instance; // Static variable to hold the single instance
    private List<PersonCard> innerList = new ArrayList<>();

    // Private constructor to prevent instantiation from outside
    private CardBox() {
    }
    

    // CR_1 : The getInstance() method

    // Static method to get the single instance of CardBox
    public static CardBox getInstance() {
        if (instance == null) {
            instance = new CardBox();
        }
        return instance;
    }

    // CR_2
    // Method to save PersonCard objects permanently
    public void save() throws CardBoxStorageException {
        try (ObjectOutputStream outputStream = new ObjectOutputStream(new FileOutputStream("personcards.dat"))) {
            outputStream.writeObject(innerList);
        } catch (IOException e) {
            throw new CardBoxStorageException("Fehler beim Speichern von PersonCard-Objekten", e);
        }
    }

    // Method to load PersonCard objects from storage
    public void load() throws CardBoxStorageException {
        try (ObjectInputStream inputStream = new ObjectInputStream(new FileInputStream("personcards.dat"))) {
            // Clear existing cards before loading new ones
            innerList.clear();
            List<PersonCard> loadedCards = (List<PersonCard>) inputStream.readObject();
            innerList.addAll(loadedCards);
        } catch (IOException | ClassNotFoundException e) {
            throw new CardBoxStorageException("Fehler beim Laden von PersonCard-Objekten", e);
        }
    }

    //CR_3

    // Method to add a PersonCard to the CardBox
    public void addPersonCard(PersonCard personCard) throws CardBoxException {
        if (personCard == null) {
            throw new CardBoxException("PersonCard object is null");
        }
        if (contains(personCard)) {
            throw new CardBoxException("PersonCard with ID " + personCard.getId() + " already exists");
        }
        innerList.add(personCard);
    }

    // Method to get the current list of PersonCard objects
    public List<PersonCard> getCurrentList() {
        return innerList;
    }

    private boolean contains(PersonCard personCard) {
        int id = personCard.getId();
        for (PersonCard record : innerList) {
            if (record.getId() == id) {
                return true;
            }
        }
        return false;
    }

    // Rest of CardBox class implementation...
    // like deletePersonCard, showContent, size, etc.
}
