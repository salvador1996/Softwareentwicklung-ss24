package org.hbrs.se1.ss24.uebung2;

public class CardBoxStorageException extends Exception {
    public CardBoxStorageException(String message) {
        super(message);
    }

    public CardBoxStorageException(String message, Throwable cause) {
        super(message, cause);
    }
}
