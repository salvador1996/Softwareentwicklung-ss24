package org.hbrs.se1.ss24.uebung2;

import static org.junit.Assert.*;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class CardBoxTest {
    private CardBox cardBox;
    private List<PersonCard> initialList;

    @Before
    public void setUp() {
        cardBox = new CardBox();
        initialList = new ArrayList<>();
        initialList.add(new EnduserCard("Jack", "David", 1, true));
        initialList.add(new DeveloperCard("Janie", "Seth", 2, false));
        initialList.add(new EnduserCard("Elena", "Gabriel", 3, true));
    }

    @After
    public void tearDown() {
        File file = new File("personcards.dat");
        if (file.exists()) {
            file.delete();
        }
    }

    @Test
    public void testSaveAndLoad() {
        try {
            // Add initialList to cardBox
            for (PersonCard personCard : initialList) {
                cardBox.addPersonCard(personCard);
            }

            // Save cardBox to file
            cardBox.save();

            // Clear cardBox
            cardBox.getCurrentList().clear();

            // Load from file
            cardBox.load();

            // Retrieve loaded list
            List<PersonCard> loadedList = cardBox.getCurrentList();

            // Assert loadedList is equal to initialList
            assertEquals(initialList.size(), loadedList.size());
            for (int i = 0; i < initialList.size(); i++) {
                assertEquals(initialList.get(i).getId(), loadedList.get(i).getId());
                assertEquals(initialList.get(i).getFirstName(), loadedList.get(i).getFirstName());
                assertEquals(initialList.get(i).getLastName(), loadedList.get(i).getLastName());
                assertEquals(initialList.get(i) instanceof EnduserCard, loadedList.get(i) instanceof EnduserCard);
                assertEquals(initialList.get(i) instanceof DeveloperCard, loadedList.get(i) instanceof DeveloperCard);
            }
        } catch (CardBoxException | CardBoxStorageException e) {
            fail("Exception occurred: " + e.getMessage());
        }
    }
}
