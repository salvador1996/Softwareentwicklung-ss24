package org.hbrs.se1.ss24.uebung2;

public class Main {
    public static void main(String[] args) {
        CardBox cardBox = new CardBox();
        PersonCardView personCardView = new PersonCardView();

        // Create several PersonCard objects
        PersonCard person1 = new EnduserCard("Jack", "David", 1, true);
        PersonCard person2 = new DeveloperCard("Janie", "Seth", 2, false);
        PersonCard person3 = new EnduserCard("Elena", "Gabriel", 3, true);

        // Add them to the CardBox
        try {
            cardBox.addPersonCard(person1);
            cardBox.addPersonCard(person2);
            cardBox.addPersonCard(person3);
        } catch (CardBoxException e) {
            System.out.println("Error adding PersonCard: " + e.getMessage());
        }

        // Read all PersonCard objects using getCurrentList() method
        List<PersonCard> currentList = cardBox.getCurrentList();

        // Pass them to the PersonCardView class for output
        personCardView.showContent(currentList);
    }
}
