package org.hbrs.se1.ss24.uebung2;

import java.util.List;

public class PersonCardView {
    public void showContent(List<PersonCard> list) {
        for (PersonCard personCard : list) {
            System.out.println(personCard.toString());
        }
    }
}
